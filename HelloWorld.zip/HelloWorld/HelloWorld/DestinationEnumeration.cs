﻿using System;
namespace HelloWorld
{
	/// <summary>
	/// Destination enumeration.
	/// Enumerates the destinations of where to write to.
	/// </summary>
	public enum DestinationEnumeration
	{
		CONSOLE,
		DATABASE,
		FILE
	}
}
