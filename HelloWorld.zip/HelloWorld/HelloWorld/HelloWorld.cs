﻿using System;

namespace HelloWorld
{
	/// <summary>
	/// Main class.
	/// This class is the entry point for this exercise.
	/// It will print "Hello World" to the console.
	/// 
	/// The overall design of this solution provides an API in the HwAPI
	/// object. The HwAPI object can be extended in the future to provide a RESTful
	/// interface via extending ApiController (for example). In this way the FactoryMethod
	/// endpoint would become a RESTful API endpoint.
	/// 
	/// We also utilize a simple factory pattern to create objects that are specific to the
	/// destination of where to write the information to. In this way the specific factory objects
	/// such as ConsoleClass, FileClass, and DatabaseClass are specific to there destinations. We can
	/// imagine (for example) that the DatabaseClass object would hold the details of interfacing to
	/// Entity Framework.
	/// </summary>
	class MainClass
	{
		public static void Main(string[] args)
		{
			HwAPI hwAPI = new HwAPI(DestinationEnumeration.CONSOLE);
			IWriteTo writeTo = hwAPI.FactoryMethod();
			writeTo.writeString("Hello World");
		}
	}
}
