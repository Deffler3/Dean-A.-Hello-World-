﻿using System;
namespace HelloWorld
{
	/// <summary>
	/// Write to.
	/// Part of the overall factory pattern to create
	/// an object specific to the writing destination.
	/// </summary>
	public interface IWriteTo
	{
		void writeString(String stringToWrite);
	}
}
