﻿using System;
namespace HelloWorld
{
	/// <summary>
	/// Database class.
    /// Part of the facrtory pattern that is specific to writing 
    /// information to a database. For now we have a placeholder
    /// that writes to the console just to mimic writing to a database.
	/// </summary>
	public class DatabaseClass : IWriteTo
	{
		public DatabaseClass()
		{
		}

        public void writeString(String stringToWrite)
        {
	        Console.WriteLine("Written to DATABASE: " + stringToWrite);
		}
	}
}
