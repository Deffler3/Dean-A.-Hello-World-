﻿using System;
namespace HelloWorld
{
	/// <summary>
	/// Console class.
    /// Part of the facrtory pattern that is specific to writing
    /// information to the console.
	/// </summary>
	public class ConsoleClass : IWriteTo
	{
		public ConsoleClass()
		{
		}

        public void writeString(String stringToWrite)
        {
	        Console.WriteLine(stringToWrite);
		}
	}
}
