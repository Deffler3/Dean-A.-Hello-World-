﻿using System;

namespace HelloWorld
{
	/// <summary>
	/// Hw API.
	/// Provides extensible API interface. This can be extended
	/// in the future to eventually support mobile applications, web applications, or console
	/// applications, or windows services by extending ApiController (for example).
	/// </summary>
	public class HwAPI
	{
		private DestinationEnumeration destination;

		public HwAPI() : this(DestinationEnumeration.CONSOLE)
		{
		}

		public HwAPI(DestinationEnumeration dest)
		{
			destination = dest;
		}

		/// <summary>
		/// Factories the method.
		/// </summary>
		/// <returns>an IWriteTo object specific to the destination</returns>
		public IWriteTo FactoryMethod()
		{
			if (destination == DestinationEnumeration.CONSOLE)
			{
				return new ConsoleClass();
			}
			else if (destination == DestinationEnumeration.DATABASE)
			{
				return new DatabaseClass();
			}
			else if (destination == DestinationEnumeration.FILE)
			{
				return new FileClass();
			}
			else
			{
				return new ConsoleClass();//default
			}
		}
	}
}
