﻿using System;
namespace HelloWorld
{
	/// <summary>
	/// File class.
	/// Part of the facrtory pattern that is specific to writing
	/// information to a file. For now we have a placeholder
	/// that writes to the console just to mimic writing to a file.
	/// </summary>
	public class FileClass : IWriteTo
	{
		public FileClass()
		{
		}

		public void writeString(String stringToWrite)
		{
			Console.WriteLine("Written to FILE: " + stringToWrite);
		}
	}
}
