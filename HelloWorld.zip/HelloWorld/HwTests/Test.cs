﻿using NUnit.Framework;
using System;
using HelloWorld;

namespace HwTests
{
	/// <summary>
	/// Test.
	/// Unit tests that make sure the factory pattern is working.
	/// </summary>
	[TestFixture()]
	public class Test
	{
		/// <summary>
		/// Tests the case console.
		/// </summary>
		[Test()]
		public void TestCaseConsole()
		{
            HwAPI hwAPI = new HwAPI(DestinationEnumeration.CONSOLE);
			IWriteTo writeTo = hwAPI.FactoryMethod();
			Assert.IsInstanceOf(typeof(ConsoleClass), writeTo);
		}

		/// <summary>
		/// Tests the case data base.
		/// </summary>
        [Test()]
        public void TestCaseDataBase()
        {
			HwAPI hwAPI = new HwAPI(DestinationEnumeration.DATABASE);
	        IWriteTo writeTo = hwAPI.FactoryMethod();
			Assert.IsInstanceOf(typeof(DatabaseClass), writeTo);
		}

        /// <summary>
        /// Tests the case file.
        /// </summary>
		[Test()]
        public void TestCaseFile()
        {
			HwAPI hwAPI = new HwAPI(DestinationEnumeration.FILE);
	        IWriteTo writeTo = hwAPI.FactoryMethod();
	        Assert.IsInstanceOf(typeof(FileClass), writeTo);
		}
	}
}
